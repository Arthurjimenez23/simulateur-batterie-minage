# Simulateur Batterie Minage

Interface Streamlit pour simuler la gestion d'une batterie alimentant une unité de minage, en fonction des prix SPOT EPEX et de la production photovoltaïque prévisionnelle.